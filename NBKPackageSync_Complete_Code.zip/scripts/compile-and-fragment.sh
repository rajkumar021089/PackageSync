#!/usr/bin/env bash
set -euo pipefail
# Non-production example: installed package must already exist.
# Usage: IS_DIR=/opt/SoftwareAG/IntegrationServer INSTANCE=default bash compile-and-fragment.sh
: "${IS_DIR:?Set IS_DIR to Integration Server installation directory}"
INSTANCE="${INSTANCE:-default}"
if [ ! -d "$IS_DIR/instances/$INSTANCE/packages/NBKPackageSync" ]; then
  echo 'ERROR: Create package NBKPackageSync with Designer first, then install complete source.' >&2
  exit 1
fi
if [ -x "$IS_DIR/instances/$INSTANCE/bin/jcode.sh" ]; then
  JCODE="$IS_DIR/instances/$INSTANCE/bin/jcode.sh"
elif [ -x "$IS_DIR/bin/jcode.sh" ]; then
  JCODE="$IS_DIR/bin/jcode.sh"
else
  echo 'ERROR: jcode.sh not found; locate it for your actual IS version and run manually.' >&2
  exit 1
fi
printf 'Using %s\n' "$JCODE"
"$JCODE" makeall NBKPackageSync
"$JCODE" fragall NBKPackageSync
printf 'Compiled/fragmented. Reload ONLY NBKPackageSync through IS Administrator/Designer.\n'
