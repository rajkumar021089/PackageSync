# NBKPackageSync 1.0: complete Java source for a native webMethods IS checker

**Target:** IS 10.15 first, Java source is Java 8-compatible; 11.1 and 12.1 require validation. **Status:** source and testable Java service implementation; NOT YET a Designer-exported/IS-installable package ZIP.  Creating service `node.ndf` and `java.frag` requires Designer or IS `jcode` on a licensed instance. No IBM runtime is bundled.

## What this compares

**MAINLINE** vs **PRODUCTION MIRROR** (direct host alias; no production writes). For every selected package, compares the `pub.assets:getChecksums` output for enabled/loaded namespace assets (Flow services, etc.) and reports:

* `MATCH`: every accessible loaded namespace asset matches. This does **not** imply full package byte equality.
* `DIFFERENT`: checksum difference or asset exists only on one server.
* `MISSING_MAINLINE`, `MISSING_MIRROR`: package absent from one of the inventories in automatic-inventory mode.
* `ERROR`: permission, connectivity, missing/disabled package, no checksums, etc.; **never** counted as a match.

Returns `outOfSyncPackages` (String List), `unverifiedPackages` (String List), `packagesReport` (Document List), `assetsReport` (Document List), and counts/flags.

**Not covered:** package `manifest.v3`, Java JARs, package resources, internal configuration, adapter connection runtime enablement, passwords, keystore/truststores, global variables outside returned namespace assets, missing namespace assets in partially loaded packages. You cannot determine which side is *newer* from unequal checksums alone. IBM supports comparing the checksum output for the **same IS version** only.

## Architecture

```
MAINLINE IS (runs nbkPackageSync.services:comparePackages)
  |
  |-- local ServerAPI.getPackages() + pub.assets:getChecksums
  |
  |-- Remote Servers alias PROD_MIRROR ---> Mirror IS (not LB)
       |-- nbkPackageSync.services:listPackages  (preferred, tiny read-only helper)
       |-- pub.assets:getChecksums               (standard built-in service)
  |
  +--> packagesReport, assetsReport, outOfSyncPackages, unverifiedPackages
```

### Why install the helper on the mirror?

For reliable automatic detection of missing packages, the mirror needs to return an authoritative installed package list. Our `listPackages` uses the **documented IS Java API `ServerAPI.getPackages()`**, and doesn't depend on an undocumented WmRoot service. The same small `NBKPackageSync` package can be generated/installed on both servers; **only Mainline invokes `comparePackages`**. Restrict Execute ACL of both services. The mirror is not the live production server.

Alternative if the mirror cannot host helper: set `inventoryMode=wmroot`, which calls `wm.server.packages:packageList` on the mirror. This is **undocumented/internal**, may be blocked or have a different response schema; a validated explicit `packages` String List is safer if it fails. With explicit `packages`, missing packages cannot be distinguished from disabled/inaccessible packages and are marked **ERROR**.

## Files

```
NBKPackageSync/code/source/nbkPackageSync/services.java    full tagged IS Java source (2 services)
designer/IMPORTS.txt                                        paste into imports section
designer/LIST_PACKAGES_METHOD_BODY.txt                      paste into listPackages method
/designer/COMPARE_PACKAGES_METHOD_BODY.txt                  paste into comparePackages method
designer/SHARED_CODE.txt                                    paste into Shared Code
scripts/compile-and-fragment.sh                             optional Linux jcode helper
examples/sample-pipeline.json                                illustrative output
/tests/...                                                  simulation stubs and test, NOT deployable
```

## Install METHOD A: Designer (simplest for your Mainline IS)

1. On **Mainline IS 10.15**, use Designer to create a package **NBKPackageSync**.
2. Create a folder `nbkPackageSync`, and under it a folder `services`.
3. Create **two Java services** in folder `nbkPackageSync.services`: `listPackages` and `comparePackages`.
4. Paste `designer/IMPORTS.txt` imports into the Java services' editable imports section (both methods share Java source for their folder).
5. Paste **only the method body** from `LIST_PACKAGES_METHOD_BODY.txt` into `listPackages` and `COMPARE_PACKAGES_METHOD_BODY.txt` into `comparePackages`. Paste `SHARED_CODE.txt` in Shared Code, not inside either method.
6. Specify input and output signature below, then Save/Compile in Designer.
7. Test `listPackages` on Mainline. Run `comparePackages` with an **explicit list of 1-2 known packages** before auto-discovery. This tests checksum permission and mirror connectivity.
8. On the non-production **mirror IS**, install/export the `NBKPackageSync` package **after Mainline compilation**. The mirror must have Execute ACL permission allowing the alias credential to call `listPackages`. No changed business package is required.
9. Set a restrictive Execute ACL on both Java services. Do **not** expose the checker over API Gateway. Create a Remote Server alias `PROD_MIRROR` pointing to the mirror IS's specific port, using approved credentials, preferably TLS. Do not point at LB and do not configure a retry server.
10. Run automatic discovery with `remoteAlias=PROD_MIRROR`, `includePrefix=NBK`, `inventoryMode=helper`, `onlyDifferences=true`. Inspect `complete` AND `unverifiedPackages` before considering the audit valid.

**No actual package ZIP can be generated here without real namespace `node.ndf`/`java.frag`.** After Designer compiles the services, export the package from Designer/IS Administrator to create a genuine installable ZIP for the mirror and future reuse. IBM advises against hand-editing `.ndf` files.

### Designer service inputs and outputs

`nbkPackageSync.services:listPackages` has no inputs. Outputs:
- `packageNames` **String List**, `count` String, `source` String.

`nbkPackageSync.services:comparePackages` inputs:
- `remoteAlias`: String, **required** (e.g. `PROD_MIRROR`)
- `packages`: String List, optional (explicit package names, skip discovery)
- `includePrefix`: String, optional (`NBK` to select packages starting with NBK, empty = every non-Wm package)
- `excludePackages`: String List, optional (e.g. `NBKLoggingPub`)
- `inventoryMode`: String, optional, default `helper`; alternative `wmroot`
- `onlyDifferences`: String, optional, `true` or `false`

Outputs:
- `outOfSyncPackages`: String List (confirmed different / missing; excludes ERROR)
- `unverifiedPackages`: String List (ERROR statuses)
- `packagesReport`: Document List with Strings `package`, `status`, `mainlineAssets`, `mirrorAssets`, `differentAssets`, `error`
- `assetsReport`: Document List with Strings `package`, `assetName`, `status`, `mainlineChecksum`, `mirrorChecksum`
- `comparedPackages`, `matchingPackages`, `differentPackages`, `missingMainlinePackages`, `missingMirrorPackages`, `errorPackages`: String counts
- `complete`, `hasDifferences`: String `true`/`false`
- `comparisonLevel`, `inventorySource`: String

**Important:** `complete=true` means no API errors in the checksum comparison. It does **not** prove an IS package loaded all expected assets or that non-namespace files are equal. Compare only identical IS versions with matching permissions and correct package load states.

### Test run input

```
remoteAlias:      PROD_MIRROR
packages:         [NBKAccounts, NBKPayments] (String List)
onlyDifferences:  true
```

### Full run input

```
remoteAlias:      PROD_MIRROR
inventoryMode:    helper
includePrefix:    NBK
excludePackages:  [NBKLoggingPub] (optional)
onlyDifferences:  true
```

## Install METHOD B: IBM `jcode` on a non-production IS host

Requires an existing valid **NBKPackageSync package** created through Designer/IS Administrator (you can create the package and both Java services first), and the appropriate IS `jcode.sh` / `jcode.bat` utility. `jcode` can compile Java and generate namespace metadata; file locations and invocation may differ by version and OS.

1. Back up your `NBKPackageSync` folder.
2. Copy `NBKPackageSync/code/source/nbkPackageSync/services.java` into your real instance's `packages/NBKPackageSync/code/source/nbkPackageSync/services.java` (never into `WmRoot`).
3. Set `IS_DIR` to the actual IS installation, invoke its `jcode makeall NBKPackageSync`, then `jcode fragall NBKPackageSync`. Alternatively review `scripts/compile-and-fragment.sh` for a guarded example.
4. Reload `NBKPackageSync` only, using Admin/Designer; validate both services and signatures.
5. Export via IS Administrator/Designer to obtain a genuine package ZIP.

## Test included

Compiles with deliberately simple IData/Service/ServerAPI simulation stubs, which MUST NOT be copied into IS:

```bash
bash tests/run-tests.sh
```

Expected: `PASS: 3 simulated scenarios ...`. These are **logic simulations only**, not integration tests on a real IS. Live service compilation, alias handling, WmRoot fallback and permissions still need validation on a licensed Mainline and mirror pair.

## Production/Bank safety

- Read-only service logic: calls only `ServerAPI.getPackages`, `pub.assets:getChecksums`, and `pub.remote:invoke` (which invokes `listPackages` or optional WmRoot inventory).
- Never run the tool with an alias pointing to an LB, primary production node or a retry host. Test on 2 packages before scanning ~200.
- The remote caller's permissions must include Execute on called services and List on namespace assets. Missing List rights cause `ERROR` rather than false `MATCH`.
- Scanning all 200 packages can be expensive; schedule off-peak. No asynchronous/background execution is implemented in this utility.
- Store final report only in approved locations. Checksums and service names can be operationally sensitive.

## Official references

- https://www.ibm.com/docs/en/webmethods-integration/wm-integration-server/11.1.0?topic=folder-pubassetsgetchecksums
- https://www.ibm.com/docs/en/webmethods-integration/wm-integration-server/10.15.0?topic=guide-remote-folder
- https://www.ibm.com/docs/en/webmethods-integration/wm-designer/10.15.0?topic=help-building-java-services-in-your-own-ide
- https://docs.webmethods.io/on-premises/webmethods-integration-server/en/11.1.0/related/11-1_Integration_Server_Java_API_Reference/index-all.html
