import com.wm.data.*;
import nbkPackageSync.services;
public class SmokeTest {
  static void check(boolean v,String description){if(!v)throw new AssertionError(description);}
  static String get(IData d,String k){return IDataUtil.getString(d.getCursor(), k);}
  public static void main(String[] args) throws Exception {
    IData inventory=IDataFactory.create();
    services.listPackages(inventory);
    check("5".equals(get(inventory,"count")), "local inventory count");
    check(IDataUtil.getStringArray(inventory.getCursor(),"packageNames").length==5, "local package array");
    IData input=IDataFactory.create();
    IDataUtil.put(input.getCursor(), "remoteAlias", "PROD_MIRROR");
    IDataUtil.put(input.getCursor(), "includePrefix", "NBK");
    services.comparePackages(input);
    check("4".equals(get(input,"comparedPackages")), "count");
    check("1".equals(get(input,"matchingPackages")), "match count");
    check("1".equals(get(input,"differentPackages")), "different count");
    check("1".equals(get(input,"missingMirrorPackages")), "mainline-only");
    check("1".equals(get(input,"missingMainlinePackages")), "mirror-only");
    check("0".equals(get(input,"errorPackages")), "no errors");
    check(IDataUtil.getStringArray(input.getCursor(),"outOfSyncPackages").length == 3, "out-of-sync list");
    check("true".equals(get(input,"complete")), "complete");
    IData[] a = IDataUtil.getIDataArray(input.getCursor(),"assetsReport");
    check(a.length==1 && "NBKPayments.services:validatePayment".equals(get(a[0],"assetName")), "changed flow");
    IData missing=IDataFactory.create();
    IDataUtil.put(missing.getCursor(),"remoteAlias","PROD_MIRROR");
    IDataUtil.put(missing.getCursor(),"packages",new String[]{"NBKAccounts","NBKError"});
    IDataUtil.put(missing.getCursor(),"onlyDifferences","true");
    services.comparePackages(missing);
    check("1".equals(get(missing,"errorPackages")), "failed explicit package is error");
    check("false".equals(get(missing,"complete")), "failed audit not complete");
    IData[] rows=IDataUtil.getIDataArray(missing.getCursor(),"packagesReport");
    check(rows.length==1 && "ERROR".equals(get(rows[0],"status")), "only differences filter");
    IData fallback=IDataFactory.create();
    IDataUtil.put(fallback.getCursor(),"remoteAlias","PROD_MIRROR");
    IDataUtil.put(fallback.getCursor(),"inventoryMode","wmroot");
    services.comparePackages(fallback);
    check("4".equals(get(fallback,"comparedPackages")), "WmRoot alternative");
    System.out.println("PASS: 3 simulated scenarios and checksum diff report, helper inventory, fallback, errors.");
  }
}
