package com.wm.data;
public class IDataCursor {
  public final IData data;
  public IDataCursor(IData d) {data=d;}
  public void destroy() {}
}
