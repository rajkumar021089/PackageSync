package com.wm.data;
import java.util.Map;
public class IData {
  public final Map<String,Object> data = new java.util.LinkedHashMap<String,Object>();
  public IDataCursor getCursor() {return new IDataCursor(this);}
}
