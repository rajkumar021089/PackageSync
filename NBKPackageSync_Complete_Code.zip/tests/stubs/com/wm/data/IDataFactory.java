package com.wm.data;
public class IDataFactory {public static IData create() {return new IData();}}
