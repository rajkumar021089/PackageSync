package com.wm.data;
public class IDataUtil {
  public static Object get(IDataCursor c,String key) {return c.data.data.get(key);}
  public static String getString(IDataCursor c,String key){Object o=get(c,key); return o instanceof String?(String)o:null;}
  public static String[] getStringArray(IDataCursor c,String key){Object o=get(c,key); return o instanceof String[]?(String[])o:null;}
  public static IData[] getIDataArray(IDataCursor c,String key){Object o=get(c,key);return o instanceof IData[]?(IData[])o:null;}
  public static void put(IDataCursor c,String key,Object v){c.data.data.put(key,v);}
}
