package com.wm.app.b2b.server;
import com.wm.data.*;
public class Service {
  public static IData doInvoke(String iface, String method, IData input) throws Exception {
    boolean remote = "pub.remote".equals(iface) && "invoke".equals(method);
    String service = remote ? IDataUtil.getString(input.getCursor(), "$service") : iface + ":" + method;
    if (remote && !"PROD_MIRROR".equals(IDataUtil.getString(input.getCursor(), "$alias")))
       throw new ServiceException("Bad alias");
    String side = remote ? "mirror" : "mainline";
    IData out = IDataFactory.create();
    if ("nbkPackageSync.services:listPackages".equals(service)) {
      IDataUtil.put(out.getCursor(), "packageNames", new String[]{"NBKAccounts", "NBKPayments", "NBKMirrorOnly", "WmPublic", "NBKPackageSync"});
      return out;
    }
    if ("wm.server.packages:packageList".equals(service)) {
      String[] names = new String[]{"NBKAccounts", "NBKPayments", "NBKMirrorOnly", "WmPublic"};
      IData[] rows = new IData[names.length];
      for (int i=0;i<names.length;i++) {rows[i]=IDataFactory.create();IDataUtil.put(rows[i].getCursor(),"name",names[i]);}
      IDataUtil.put(out.getCursor(), "packages", rows); return out;
    }
    if ("pub.assets:getChecksums".equals(service)) {
      String pkg = IDataUtil.getStringArray(input.getCursor(), "packages")[0];
      if ("NBKError".equals(pkg)) throw new ServiceException("Simulated absent or disabled package");
      IData[] rows;
      if ("NBKAccounts".equals(pkg)) rows=checks(new String[]{"NBKAccounts.services:getBalance"},new String[]{"same"});
      else if ("NBKPayments".equals(pkg)) rows=checks(new String[]{"NBKPayments.services:validatePayment", "NBKPayments.services:submitPayment"}, new String[]{remote?"old":"new", "same"});
      else rows=checks(new String[]{pkg + ".services:one"},new String[]{"same"});
      IDataUtil.put(out.getCursor(), "checksums", rows); return out;
    }
    throw new ServiceException("Unexpected service: " + service);
  }
  static IData[] checks(String[] names,String[] sums) {
    IData[] rows = new IData[names.length];
    for(int i=0;i<names.length;i++){rows[i]=IDataFactory.create();IDataCursor c=rows[i].getCursor();IDataUtil.put(c,"name",names[i]);IDataUtil.put(c,"checksum",sums[i]);IDataUtil.put(c,"package",names[i].split("\\.")[0]);c.destroy();}
    return rows;
  }
}
