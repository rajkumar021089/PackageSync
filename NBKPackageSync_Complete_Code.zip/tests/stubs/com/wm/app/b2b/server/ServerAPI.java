package com.wm.app.b2b.server;
public class ServerAPI {
    public static String[] getPackages() {
        return new String[]{"NBKAccounts", "NBKPayments", "NBKLocalOnly", "WmPublic", "NBKPackageSync"};
    }
}
