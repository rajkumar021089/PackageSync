#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
javac --release 8 -Xlint:-options -d "$TMP" \
  $(find "$ROOT/tests/stubs" -name '*.java') \
  "$ROOT/NBKPackageSync/code/source/nbkPackageSync/services.java" \
  "$ROOT/tests/SmokeTest.java"
java -cp "$TMP" SmokeTest
